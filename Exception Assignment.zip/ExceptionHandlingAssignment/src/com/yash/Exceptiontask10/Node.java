package com.yash.Exceptiontask10;
public class Node {
	
		public int data;
	    public Node left;
		public Node right;
	     
	    public Node(int d) {
	        data = d;
	        left = right = null;
	    }
	}


