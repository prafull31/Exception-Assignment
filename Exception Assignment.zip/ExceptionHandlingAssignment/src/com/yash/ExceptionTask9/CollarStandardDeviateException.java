package com.yash.ExceptionTask9;

public class CollarStandardDeviateException extends RuntimeException {
	
	public CollarStandardDeviateException(String s) {
		super(s);
	}
}