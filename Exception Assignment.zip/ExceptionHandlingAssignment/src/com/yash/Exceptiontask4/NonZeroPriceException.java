package com.yash.Exceptiontask4;

public class NonZeroPriceException extends Exception
{
	NonZeroPriceException(String msg)
	{
		super(msg);
	}
}
