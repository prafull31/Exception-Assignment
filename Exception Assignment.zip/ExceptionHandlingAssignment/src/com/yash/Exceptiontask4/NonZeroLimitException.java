package com.yash.Exceptiontask4;

public class NonZeroLimitException {

}
