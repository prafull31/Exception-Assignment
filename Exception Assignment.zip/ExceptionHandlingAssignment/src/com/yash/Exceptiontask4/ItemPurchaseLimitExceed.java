package com.yash.Exceptiontask4;

public class ItemPurchaseLimitExceed extends Exception
{
	ItemPurchaseLimitExceed (String msg)
	{
		super(msg);
	}
}
