package com.yash.ExceptionTask8;

public class PasswordFormatException extends Exception {
	public PasswordFormatException(String msg)
	{
		super(msg);
	}

}
