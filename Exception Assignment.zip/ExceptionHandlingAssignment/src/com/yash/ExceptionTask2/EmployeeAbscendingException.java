package com.yash.ExceptionTask2;

public class EmployeeAbscendingException extends Exception {
	public EmployeeAbscendingException(String msg)
	{
		super(msg);
	}

}
