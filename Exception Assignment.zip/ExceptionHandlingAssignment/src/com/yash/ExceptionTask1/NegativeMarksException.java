package com.yash.ExceptionTask1;

public class NegativeMarksException extends Exception {
	public NegativeMarksException(String msg)
	{
		super(msg);
	}

}
