package com.yash.ExceptionTask1;

public class FailInOneSubject extends Exception {
	public FailInOneSubject(String msg)
	{
		super(msg);
	}

}
