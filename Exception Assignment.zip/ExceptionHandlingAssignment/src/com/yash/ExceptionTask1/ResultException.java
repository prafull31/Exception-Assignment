package com.yash.ExceptionTask1;

public class ResultException extends RuntimeException{
	public ResultException(String msg)
	{
		super(msg);
	}

}
